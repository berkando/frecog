+ https://github.com/auduno/clmtrackr
+ http://inspirit.github.io/jsfeat/sample_bbf_face.html
